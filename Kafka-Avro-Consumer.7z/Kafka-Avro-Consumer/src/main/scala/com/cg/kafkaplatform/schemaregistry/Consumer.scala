package com.cg.kafkaplatform.schemaregistry

import io.confluent.kafka.schemaregistry.client.{CachedSchemaRegistryClient, SchemaRegistryClient}
import io.confluent.kafka.serializers.AbstractKafkaAvroDeserializer
import org.apache.avro.Schema
import org.apache.avro.generic.GenericRecord
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.avro.SchemaConverters

import scala.collection.JavaConverters.mapAsJavaMapConverter

object Consumer {
  private val TOPIC = "topic-test-rec"
  private val KAFKA_URL = "pkc-epwny.eastus.azure.confluent.cloud:9092"
  private val SCHEMA_REGISTRY_URL = "https://psrc-e8vk0.southeastasia.azure.confluent.cloud"

  val props = Map(
    "basic.auth.credentials.source" -> "USER_INFO",
    "schema.registry.basic.auth.user.info" -> "QXIJEWRYAT5QQK6D:wvDfgXDLRQnivgLCovDY4ZbDL0laOu55eLf6Jd2t/rz4wYZHfFY+PcjJw51pd41V"
  ).asJava

  private val schemaRegistryClient = new CachedSchemaRegistryClient(SCHEMA_REGISTRY_URL, 1000,props)
  private val kafkaAvroDeserializer = new AvroDeserializer(schemaRegistryClient)

  private val avroSchema = schemaRegistryClient.getLatestSchemaMetadata(TOPIC + "-value").getSchema
  println("avro schema "+avroSchema)
  private var sparkSchema = SchemaConverters.toSqlType(new Schema.Parser().parse(avroSchema))
  println("spark schema "+sparkSchema)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder
      .appName("ConfluentConsumer")
      .master("local[*]")
      .getOrCreate()
    println("Spark session created.")
    spark.sparkContext.setLogLevel("WARN")
    println("deserialzer started")
    spark.udf.register("deserialize", (bytes: Array[Byte]) =>
      DeserializerWrapper.deserializer.deserialize(bytes)
    )
    println("deserialzer ended")

    val kafkaDataFrame = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", KAFKA_URL)
      .option("subscribe", TOPIC)
      .option("startingOffsets", "latest")
      .option("kafka.security.protocol","SASL_SSL")
      .option("kafka.sasl.mechanism", "PLAIN")
      .option("kafka.sasl.jaas.config", """org.apache.kafka.common.security.plain.PlainLoginModule required username="YMTT5OIXNOVYWCBF" password="qvrxRc6ZPNEAl6p0UKJNI36xk0bWrJLBftY6236dzPZjC82QFfDCF8DIb0yxIfj4";""")
      .option("checkpointLocation", "C:\\checkpoint-json")
      .option("failOnDataLoss", "false")
      .load()
    println("kafka read")
    kafkaDataFrame.printSchema()

    val valueDataFrame = kafkaDataFrame.selectExpr("""deserialize(value) AS message""")
    valueDataFrame.printSchema()

    import org.apache.spark.sql.functions._

    val formattedDataFrame = valueDataFrame.select(
      from_json(col("message"), sparkSchema.dataType).alias("parsed_value"))
      .select("parsed_value.*")
    formattedDataFrame.printSchema()

    formattedDataFrame
      .writeStream
      .format("console")
      .option("truncate", false)
      .start()
      .awaitTermination()
  }

  object DeserializerWrapper {
    val deserializer = kafkaAvroDeserializer
  }

  class AvroDeserializer extends AbstractKafkaAvroDeserializer {
    def this(client: SchemaRegistryClient) {
      this()
      this.schemaRegistry = client
    }

    override def deserialize(bytes: Array[Byte]): String = {
      val genericRecord = super.deserialize(bytes).asInstanceOf[GenericRecord]
      genericRecord.toString
    }
  }

}

