import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, struct, to_json}


object KafkaJsonProd extends App{
  private val topic = "jsonap1"
  private val kafkaUrl = "pkc-epwny.eastus.azure.confluent.cloud:9092"
  val spark = SparkSession.builder()
    .appName("myAppName")
    .master("local[*]")
    .getOrCreate()
  spark.sparkContext.setLogLevel("WARN")
  Logger.getRootLogger.setLevel(Level.WARN)
  // create DataFrame
  import spark.implicits._
  //    val df = Seq((3, "Alice"), (5, "Bob")).toDF("age", "name")
  //    df.show(false)
  val df1 = spark.read.format("csv").option("header", "true").load("C:\\Users\\APEKKC\\Install\\text.csv")
  val df = df1.toDF("id","name","dept")
  df.show(false)
  // convert columns into json string
  val df2 = df.select(col("id"),to_json(struct($"*"))).toDF("key", "value")
  df2.show(false)


  object MySerializerWrapper {
    val ser = new Mydeserializer
  }
  spark.udf.register("deserialize", (topic: String, bytes: Array[Byte]) =>
    MySerializerWrapper.ser.serialize(topic, bytes)
  )

  df.selectExpr("""deserialize("topic1", value) AS message""")

  // write to Kafka with jsonString as value
  df2.selectExpr("key", "value")
    .write
    .format("kafka")
    .option("kafka.bootstrap.servers", kafkaUrl)
    .option("kafka.security.protocol","SASL_SSL")
    .option("kafka.sasl.mechanism", "PLAIN")
    .option("kafka.sasl.jaas.config", """org.apache.kafka.common.security.plain.PlainLoginModule required username="YMTT5OIXNOVYWCBF" password="qvrxRc6ZPNEAl6p0UKJNI36xk0bWrJLBftY6236dzPZjC82QFfDCF8DIb0yxIfj4";""")
    .option("checkpointLocation", "C:\\checkpoint-json2")
    .option("topic", topic)
    .save()
}