import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, expr, from_json, struct, to_json}
import org.apache.spark.sql.types._

import java.util.Properties
import scala.collection.JavaConverters.mapAsJavaMapConverter

object KafkaAvro extends Serializable {
  @transient lazy val logger: Logger = Logger.getLogger(getClass.getName)


  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder()
      .master("local[*]")
      .appName("Kafka Json Sink Demo")
      .getOrCreate()

    println("Spark Session Created.")
    spark.sparkContext.setLogLevel("WARN")
    Logger.getRootLogger.setLevel(Level.WARN)

    val bootstrapServers = "pkc-epwny.eastus.azure.confluent.cloud:9092"
    val topic = "jsonnew"
    val schemaRegistryUrl ="https://psrc-e8vk0.southeastasia.azure.confluent.cloud"


    consumeAvro(spark, bootstrapServers, topic)

    spark.stop()
  }

  private def consumeAvro(spark: SparkSession, bootstrapServers: String, topic: String): Unit = {
    import spark.implicits._

    val props = Map(
      "basic.auth.credentials.source" -> "USER_INFO",
      "schema.registry.basic.auth.user.info" -> "AWFIA7BUNKORQMHQ:O6CzetYV/lP3gastJF6zs7gSyVDhDZnNrPG2/fqhNPfS1uWG1cpJ+bUYyP+dIVip"
    ).asJava

    val kafkaSourceDF = spark
      .readStream
      .format("kafka")
      .option("kafka.bootstrap.servers", bootstrapServers)
      .option("subscribe", topic)
      .option("startingOffsets", "earliest")
      .option("kafka.security.protocol", "SASL_SSL")
      .option("kafka.sasl.mechanism", "PLAIN")
      .option("kafka.sasl.jaas.config", """org.apache.kafka.common.security.plain.PlainLoginModule required username="AWFIA7BUNKORQMHQ" password="O6CzetYV/lP3gastJF6zs7gSyVDhDZnNrPG2/fqhNPfS1uWG1cpJ+bUYyP+dIVip";""")
      .option("checkpointLocation", "C:\\Users\\APEKKC\\temp_app_apeksha\\spk_ck_pnt\\ck4")
      .option("failOnDataLoss", "false")
      .load()



    val schema = StructType(List(
      StructField("event", StringType),
      StructField("trainId", IntegerType),
      StructField("line", StringType),
      StructField("stopTime", LongType),
        StructField("passengerOn", IntegerType),
        StructField("passengersOff", IntegerType)
      )
    )



    val valueDF = kafkaSourceDF.select(from_json(col("value").cast("string"), schema).alias("value"))
    valueDF.printSchema()

    val explodeDF = valueDF.selectExpr("value.event", "value.trainId", "value.line", "value.stopTime", "value.passengerOn", "value.passengersOff")
    explodeDF.printSchema()



      val Output = explodeDF
          .writeStream
          .format("console")
          .outputMode("append")
          .option("checkpointLocation", "C:\\chk-point-dir14")
          .start()
           .awaitTermination()

//    val jsonDF = explodeDF.toJSON
//
//    jsonDF.printSchema()
//
//
//    jsonDF.selectExpr( "to_json(struct(*)) AS value")
//      .writeStream
//      .format("kafka")
//      .outputMode("append")
//      .option("kafka.bootstrap.servers", bootstrapServers)
//      .option("topic", "json_data_topic")
//      .option("kafka.security.protocol", "SASL_SSL")
//      .option("kafka.sasl.mechanism", "PLAIN")
//      .option("kafka.sasl.jaas.config", """org.apache.kafka.common.security.plain.PlainLoginModule required username="AWFIA7BUNKORQMHQ" password="O6CzetYV/lP3gastJF6zs7gSyVDhDZnNrPG2/fqhNPfS1uWG1cpJ+bUYyP+dIVip";""")
//      .option("checkpointLocation", "C:\\chk-point-dirnew2")
//      .start()
//      .awaitTermination()


    }
}