package com.supergloo

import com.supergloo.KafkaStreamsJoins.{kStreamToKStreamJoin, kStreamToKStreamLeftJoin, kStreamToKStreamOuterJoin, kStreamnew}
import org.apache.kafka.common.serialization.Serdes
import org.apache.kafka.streams.scala.kstream.KTable
import org.apache.kafka.streams.{KafkaStreams, StreamsConfig}


import java.io.FileReader
import java.util.Properties

object StreamsJoin {

    val configFileName = "java.config"
   val props = buildProperties(configFileName)

//  val props: Properties = {
//    val p = new Properties()
//    p.put(StreamsConfig.APPLICATION_ID_CONFIG, "kafka-streams-join1")
//    p.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092")
//    p
//  }


  def main(args: Array[String]): Unit = {

    println("Inside main")

    println("config...:" + props)


    //kStreamToKStreamLeftJoin("str1","str2","str-out","join-store")
    val streams = new KafkaStreams(kStreamToKStreamOuterJoin("t3", "t4", "t7", "kstream2"), props)
    println("stream...:" + streams)



    streams.start()

    println("stream application started...")
    println("stopped app")
  }

    def buildProperties(configFileName: String): Properties = {
      import org.apache.kafka.clients.consumer.ConsumerConfig
      import org.apache.kafka.streams.StreamsConfig
      val properties = new Properties()
      properties.put(StreamsConfig.APPLICATION_ID_CONFIG, "application2")
      // Disable caching to print the aggregation value after each record
      properties.put(StreamsConfig.CACHE_MAX_BYTES_BUFFERING_CONFIG, "0")
      properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")
      properties.put(StreamsConfig.REPLICATION_FACTOR_CONFIG, "-1");
      properties.load(new FileReader(configFileName))
      properties
    }
}