package com.cg.kafkaplatform.produce

import com.sun.jdi.{DoubleType, IntegerType, LongType}
import org.apache.avro.Schema.Parser
import org.apache.avro.generic.GenericData
import org.apache.avro.generic.GenericData.StringType
import org.apache.kafka.clients.producer.{Callback, KafkaProducer, ProducerConfig, ProducerRecord, RecordMetadata}

import java.io.FileReader
import java.util.Properties

object Producer {
  def main(args: Array[String]): Unit = {
    val configFileName = "java.config"
    val topicName = "topic-test-rec"
    // val topicName = "test_comp_fwd"
    val props = buildProperties(configFileName)
    val producer = new KafkaProducer[String, GenericData.Record](props)
    val callback = new Callback {
      override def onCompletion(metadata: RecordMetadata, exception: Exception): Unit = {
        Option(exception) match {
          case Some(err) => println(s"Failed to produce: $err")
          case None => println(s"Produced record at $metadata")
        }
      }
    }
    println("Props:" + props)
    println("Producer:" + producer)

    val schemaParser = new Parser

    val key = "key1"
    //forward
    //    val valueSchemaJson =
    //      s"""
    //    {
    //      "namespace": "com.avro.records",
    //      "type": "record",
    //      "name": "User2",
    //      "fields": [
    //        {"name": "id", "type": "int"},
    //        {"name": "name","type": "string"},
    //       {"name": "address", "type": "string"},
    //        {"name": "email", "type": "string"},
    //        {"name": "dept", "type": "string"}
    //      ]
    //    }
    //  """
    //backward
    val valueSchemaJson =
    s"""
    {
      "namespace": "com.avro.records",
      "type": "record",
      "name": "User2",
      "fields": [
        {"name": "id", "type": "int"},
         {"name": "name", "type": "string"},
         {"name": "address", "type": "string"},
         {"name": "email", "type": "string"},
         {"name": "dept", "type":"string"},
         {"name": "role", "type":"string"},
         {"name": "grade","default":null, "type":["null","string"]}
      ]
    }
  """
    //val valueSchemaJson =
    //s"""
    //    {
    //      "namespace": "com.avro.records",
    //      "type": "record",
    //      "name": "User1",
    //      "fields": [
    //        {"name": "id", "type": "int"},
    //         {"name": "name", "type": "string"},
    //         {"name": "address", "type": "string"},
    //         {"name": "email", "type": "string"},
    //         {"name": "dept", "type":"string"},
    //         {"name": "role", "type":"string"},
    //        {"name":"contact",
    //         "type":{"type":"enum",
    //	       "name":"contact_types",
    //             "symbols":["home","mobile"]},
    //         "doc":"The method of contact"}      ]
    //    }
    //  """
    val valueSchemaAvro = schemaParser.parse(valueSchemaJson)
    println("valueSchemaAvro" + valueSchemaAvro)
    val avroRecord = new GenericData.Record(valueSchemaAvro)
    avroRecord.put("id", 2)
    avroRecord.put("name", "xyz")
    avroRecord.put("address", "BLR")
    avroRecord.put("email", "xyz@gmail.com")
    avroRecord.put("dept", "AB")
    avroRecord.put("role", "SE")
    //avroRecord.put("grade", "A2")

    try {
      val record = new ProducerRecord(topicName, key, avroRecord)
      println("avroRecord" + avroRecord)
      val ack = producer.send(record,callback).get()
      println(s"${ack.toString} written to partition ${ack.partition.toString}")
    }
    catch {
      case e: Throwable =>
        println(e.getMessage)
    }

  }
  def buildProperties(configFileName: String): Properties = {
    val properties: Properties = new Properties
    properties.load(new FileReader(configFileName))
    properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroSerializer")
    properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, "io.confluent.kafka.serializers.KafkaAvroSerializer")
    properties
  }
}
